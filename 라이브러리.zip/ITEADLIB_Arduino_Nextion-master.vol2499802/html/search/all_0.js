var searchData=
[
  ['addvalue',['addValue',['../class_nex_waveform.html#a5b04ea7397b784947b845e2a03fc77e4',1,'NexWaveform']]],
  ['analog_5fwrite',['analog_write',['../class_nex_gpio.html#af21eb91b041d149193bc716202d4a462',1,'NexGpio']]],
  ['attachpop',['attachPop',['../class_nex_touch.html#a4da1c4fcdfadb7eabfb9ccaba9ecad11',1,'NexTouch']]],
  ['attachpush',['attachPush',['../class_nex_touch.html#a685a753aae5eb9fb9866a7807a310132',1,'NexTouch']]],
  ['attachtimer',['attachTimer',['../class_nex_timer.html#ae6f1ae95ef40b8bc6f482185b1ec5175',1,'NexTimer']]]
];
