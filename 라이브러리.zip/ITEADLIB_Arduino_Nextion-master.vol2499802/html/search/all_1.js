var searchData=
[
  ['configuration',['Configuration',['../group___configuration.html',1,'']]],
  ['core_20api',['Core API',['../group___core_a_p_i.html',1,'']]]
];
